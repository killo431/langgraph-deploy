# GitOps Webhook Runner for LangGraph BMAD Workflows

This service connects GitHub Pull Request / Spec events and ArgoCD Continuous Delivery webhooks directly to your self-hosted **LangGraph Agent Server**.

## Features
- **GitHub Webhook Listener**: Automatically detects newly opened PRs or issues labeled `bmad-spec` and triggers a BMAD SDLC Sprint (PM -> Architect -> Scrum Master -> Developer -> QA).
- **ArgoCD Sync Listener**: Captures deployment sync states and triggers post-deploy automated QA agent checks.
- **HMAC Signature Verification**: Validates incoming payload integrity via SHA256 webhook secrets.

## Deployment with Docker Compose

1. Copy into your `langgraph-production-stack` repository directory.
2. Update `.env` with your GitHub webhook secret:
   ```env
   GITHUB_WEBHOOK_SECRET=your_github_secret_here
   ARGOCD_AUTH_TOKEN=your_argocd_token_here
   ```
3. Run the stack with the GitOps extension:
   ```bash
   docker compose -f docker-compose.yml -f docker-compose.gitops.yml up --build -d
   ```
4. Verify Webhook Runner Health:
   ```bash
   curl http://localhost:9000/health
   ```
