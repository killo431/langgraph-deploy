import os
import hmac
import hashlib
from typing import Dict, Any
from fastapi import FastAPI, Request, HTTPException, Header, BackgroundTask
import httpx
from langgraph_sdk import get_client

app = FastAPI(
    title="LangGraph GitOps & Webhook Runner",
    description="Automated Webhook Listener connecting GitHub/ArgoCD Events to BMAD Agent Workflows",
    version="1.0.0"
)

LANGGRAPH_API_URL = os.getenv("LANGGRAPH_API_URL", "http://langgraph-api:8000")
GITHUB_WEBHOOK_SECRET = os.getenv("GITHUB_WEBHOOK_SECRET", "devsecret")

def verify_github_signature(payload_body: bytes, secret: str, signature_header: str) -> bool:
    if not signature_header or not signature_header.startswith("sha256="):
        return False
    expected_signature = "sha256=" + hmac.new(secret.encode(), payload_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected_signature, signature_header)

async def trigger_bmad_sprint(feature_title: str, feature_spec: str, pr_number: int, repo_name: str):
    """Triggers the LangGraph BMAD Workflow via HTTP/SDK Client."""
    client = get_client(url=LANGGRAPH_API_URL)
    
    # 1. Create a thread for the feature sprint
    thread = await client.threads.create()
    thread_id = thread["thread_id"]
    
    # 2. Start BMAD Workflow Run
    payload = {
        "input": {
            "feature_request": f"[{repo_name} PR #{pr_number}] {feature_title}

Spec Content:
{feature_spec}"
        },
        "config": {
            "configurable": {
                "thread_id": thread_id,
                "github_repo": repo_name,
                "pr_number": pr_number
            }
        }
    }
    
    run = await client.runs.create(
        thread_id=thread_id,
        assistant_id="bmad_sdlc",
        input=payload["input"],
        config=payload["config"]
    )
    print(f"[GitOps Runner] Triggered BMAD Run {run['run_id']} for Thread {thread_id} on PR #{pr_number}")

@app.get("/health")
def health():
    return {"status": "ok", "langgraph_url": LANGGRAPH_API_URL}

@app.post("/webhooks/github")
async def github_webhook(
    request: Request,
    x_hub_signature_256: str = Header(None),
    x_github_event: str = Header(None)
):
    body = await request.body()
    
    # Verify Secret in Production
    if GITHUB_WEBHOOK_SECRET != "devsecret":
        if not verify_github_signature(body, GITHUB_WEBHOOK_SECRET, x_hub_signature_256):
            raise HTTPException(status_code=401, detail="Invalid HMAC Signature")

    payload = await request.json()

    # Handle Pull Request or Issue with 'spec' label
    if x_github_event == "pull_request" and payload.get("action") in ["opened", "synchronize", "labeled"]:
        pr = payload.get("pull_request", {})
        title = pr.get("title", "Untitled Feature")
        body_text = pr.get("body", "No description provided.")
        pr_number = pr.get("number", 0)
        repo_name = payload.get("repository", {}).get("full_name", "unknown/repo")
        
        # Check if labeled for BMAD workflow
        labels = [l.get("name") for l in pr.get("labels", [])]
        if "bmad-spec" in labels or "agent-dev" in labels or payload.get("action") == "opened":
            background_tasks = BackgroundTask(trigger_bmad_sprint, title, body_text, pr_number, repo_name)
            return {"message": f"Triggering BMAD Agent Sprint for PR #{pr_number}", "background": True, "task": background_tasks}

    return {"message": "Event ignored", "event": x_github_event}

@app.post("/webhooks/argocd")
async def argocd_webhook(payload: Dict[str, Any]):
    """Listens for ArgoCD Sync Status & Phase Gate Promotions."""
    app_name = payload.get("app", {}).get("metadata", {}).get("name")
    sync_status = payload.get("app", {}).get("status", {}).get("sync", {}).get("status")
    health_status = payload.get("app", {}).get("status", {}).get("health", {}).get("status")

    print(f"[ArgoCD Event] App: {app_name} | Sync: {sync_status} | Health: {health_status}")
    return {"status": "received", "app": app_name, "sync": sync_status, "health": health_status}
