import json
import os

def load_langgraph_config(config_path: str = "langgraph.json") -> dict:
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            return json.load(f)
    return {}

def validate_environment():
    required_keys = ["DATABASE_URI", "REDIS_URI"]
    missing = [key for key in required_keys if not os.environ.get(key)]
    return {"valid": len(missing) == 0, "missing": missing}
