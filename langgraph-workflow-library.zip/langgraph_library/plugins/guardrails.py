import re
from typing import Dict, Any, Callable
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage

class EnterpriseGuardrailPlugin:
    """Middleware plugin for input sanitization, PII redacting, and security rails."""
    def __init__(self, redact_pii: bool = True):
        self.redact_pii = redact_pii
        self.email_pattern = re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')

    def sanitize_input(self, text: str) -> str:
        if self.redact_pii:
            return self.email_pattern.sub("[REDACTED_EMAIL]", text)
        return text

    def wrap_node_with_guardrails(self, node_fn: Callable) -> Callable:
        def guarded_node(state: Dict[str, Any], *args, **kwargs):
            if "messages" in state and state["messages"]:
                last_msg = state["messages"][-1]
                if isinstance(last_msg, HumanMessage) and isinstance(last_msg.content, str):
                    last_msg.content = self.sanitize_input(last_msg.content)
            return node_fn(state, *args, **kwargs)
        return guarded_node
