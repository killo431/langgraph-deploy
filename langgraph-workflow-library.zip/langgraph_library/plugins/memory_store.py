from typing import Tuple, List, Dict, Any
from langgraph.runtime import Runtime

class CrossThreadMemoryPlugin:
    """Plugin to interact with LangGraph BaseStore for persistent cross-thread memories."""
    
    @staticmethod
    async def search_user_memories(runtime: Runtime, user_id: str, query: str, limit: int = 3) -> List[Dict[str, Any]]:
        namespace = (user_id, "memories")
        items = await runtime.store.asearch(namespace, query=query, limit=limit)
        return [item.value for item in items]

    @staticmethod
    async def save_user_memory(runtime: Runtime, user_id: str, memory_id: str, memory_data: Dict[str, Any]):
        namespace = (user_id, "memories")
        await runtime.store.aput(namespace, memory_id, memory_data)
