from typing import Dict, Any, List
from langgraph.prebuilt import ToolNode

class MCPAdapterPlugin:
    """Plugin to dynamically load Anthropic Model Context Protocol (MCP) tools into LangGraph."""
    def __init__(self, server_configs: Dict[str, Any]):
        self.server_configs = server_configs

    async def get_tool_node(self) -> ToolNode:
        try:
            from langchain_mcp_adapters.client import MultiServerMCPClient
            client = MultiServerMCPClient(self.server_configs)
            tools = await client.get_tools()
            return ToolNode(tools)
        except ImportError:
            raise ImportError("Please install `pip install langchain-mcp-adapters` to use MCP tools.")
