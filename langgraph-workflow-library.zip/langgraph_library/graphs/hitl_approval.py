from typing import TypedDict, Annotated
from langchain_core.messages import AnyMessage, AIMessage
from langgraph.graph import StateGraph, START, END, add_messages
from langgraph.types import interrupt, Command

class HITLState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    action_request: str
    approval_status: str

def plan_action_node(state: HITLState):
    request = "Execute database schema migration and deploy v2 API."
    return {"action_request": request}

def human_approval_node(state: HITLState) -> Command[Literal["execute_action", "cancel_action"]]:
    decision = interrupt({"question": "Approve action execution?", "details": state["action_request"]})
    if isinstance(decision, dict) and decision.get("approved"):
        return Command(goto="execute_action", update={"approval_status": "approved"})
    return Command(goto="cancel_action", update={"approval_status": "rejected"})

def execute_action(state: HITLState):
    return {"messages": [AIMessage(content="Action executed successfully following human approval.")]}

def cancel_action(state: HITLState):
    return {"messages": [AIMessage(content="Action cancelled by human decision.")]}

def create_hitl_graph():
    builder = StateGraph(HITLState)
    builder.add_node("plan_action_node", plan_action_node)
    builder.add_node("human_approval_node", human_approval_node)
    builder.add_node("execute_action", execute_action)
    builder.add_node("cancel_action", cancel_action)
    
    builder.add_edge(START, "plan_action_node")
    builder.add_edge("plan_action_node", "human_approval_node")
    builder.add_edge("execute_action", END)
    builder.add_edge("cancel_action", END)
    return builder.compile()
