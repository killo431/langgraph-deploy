from typing import TypedDict, Annotated
import operator
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send

class MapReduceState(TypedDict):
    topics: list[str]
    results: Annotated[list[str], operator.add]

class WorkerInput(TypedDict):
    topic: str

def generate_topics(state: MapReduceState):
    return {"topics": ["performance_tuning", "security_audit", "cost_optimization"]}

def map_workers(state: MapReduceState):
    return [Send("worker_task", {"topic": t}) for t in state["topics"]]

def worker_task(state: WorkerInput):
    analysis = f"Completed in-depth analysis for section: {state['topic']}"
    return {"results": [analysis]}

def aggregate_results(state: MapReduceState):
    summary = "Aggregate Report:\n" + "\n".join(state["results"])
    return {"results": [summary]}

def create_map_reduce_graph():
    builder = StateGraph(MapReduceState)
    builder.add_node("generate_topics", generate_topics)
    builder.add_node("worker_task", worker_task)
    builder.add_node("aggregate_results", aggregate_results)
    
    builder.add_edge(START, "generate_topics")
    builder.add_conditional_edges("generate_topics", map_workers, ["worker_task"])
    builder.add_edge("worker_task", "aggregate_results")
    builder.add_edge("aggregate_results", END)
    return builder.compile()
