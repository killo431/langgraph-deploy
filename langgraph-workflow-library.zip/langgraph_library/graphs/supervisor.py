from typing import TypedDict, Annotated, Literal
from langchain_core.messages import AnyMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, START, END, add_messages
from langgraph.types import Command

class SupervisorState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    next_agent: str
    task_complete: bool

def supervisor_node(state: SupervisorState) -> Command[Literal["researcher_agent", "coder_agent", "__end__"]]:
    last_msg = state["messages"][-1].content.lower() if state["messages"] else ""
    if "code" in last_msg or "script" in last_msg:
        return Command(goto="coder_agent", update={"next_agent": "coder_agent"})
    elif "research" in last_msg or "data" in last_msg:
        return Command(goto="researcher_agent", update={"next_agent": "researcher_agent"})
    else:
        return Command(goto="__end__", update={"task_complete": True})

def researcher_agent(state: SupervisorState) -> Command[Literal["supervisor_node"]]:
    res = AIMessage(content="[Researcher] Found relevant empirical data in source knowledge base.")
    return Command(goto="supervisor_node", update={"messages": [res]})

def coder_agent(state: SupervisorState) -> Command[Literal["supervisor_node"]]:
    res = AIMessage(content="[Coder] Implemented Python module and verified syntax.")
    return Command(goto="supervisor_node", update={"messages": [res]})

def create_supervisor_graph():
    builder = StateGraph(SupervisorState)
    builder.add_node("supervisor_node", supervisor_node)
    builder.add_node("researcher_agent", researcher_agent)
    builder.add_node("coder_agent", coder_agent)
    builder.add_edge(START, "supervisor_node")
    return builder.compile()
