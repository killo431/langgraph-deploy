from typing import TypedDict, Annotated
from langchain_core.messages import AnyMessage, AIMessage
from langgraph.graph import StateGraph, START, END, add_messages

class EvalState(TypedDict):
    draft: str
    feedback: str
    pass_quality_gate: bool
    iteration_count: int

def generator_node(state: EvalState):
    count = state.get("iteration_count", 0) + 1
    new_draft = f"Draft v{count}: Refined content addressing feedback: {state.get('feedback', 'Initial request')}"
    return {"draft": new_draft, "iteration_count": count}

def evaluator_node(state: EvalState):
    if state["iteration_count"] >= 2:
        return {"pass_quality_gate": True, "feedback": "Quality gate passed."}
    return {"pass_quality_gate": False, "feedback": "Add more technical specificity."}

def route_feedback(state: EvalState):
    if state["pass_quality_gate"]:
        return "approved"
    return "refine"

def create_evaluator_optimizer_graph():
    builder = StateGraph(EvalState)
    builder.add_node("generator_node", generator_node)
    builder.add_node("evaluator_node", evaluator_node)
    
    builder.add_edge(START, "generator_node")
    builder.add_edge("generator_node", "evaluator_node")
    builder.add_conditional_edges(
        "evaluator_node",
        route_feedback,
        {
            "approved": END,
            "refine": "generator_node"
        }
    )
    return builder.compile()
