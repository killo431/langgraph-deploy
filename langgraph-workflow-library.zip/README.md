# LangGraph Production Workflow & Plugin Library

This library provides ready-to-import, production-grade graphs, workflows, and enterprise plugins for LangGraph applications.

## 📦 What's Included

### 1. Ready-to-Use Graph Topologies (`langgraph_library.graphs`)
- **`supervisor.py`**: Multi-Agent Supervisor workflow using `Command(goto=...)` routing across specialized worker nodes (Researcher, Coder, Reviewer).
- **`hitl_approval.py`**: Human-in-the-loop (HITL) gate using native `interrupt()` and state resumption via `Command(resume=...)`.
- **`map_reduce.py`**: Dynamic parallel fan-out and aggregation using LangGraph's `Send` API.
- **`evaluator_optimizer.py`**: Self-correcting feedback loop for automated quality verification and iterative refinement.

### 2. Enterprise Plugins & Adapters (`langgraph_library.plugins`)
- **`mcp_adapter.py`**: Model Context Protocol (MCP) client loader integrating external stdio/HTTP tools with `ToolNode`.
- **`guardrails.py`**: Enterprise middleware hooks for PII sanitization, input validation, and guardrail policies.
- **`memory_store.py`**: Long-term cross-thread semantic memory management powered by LangGraph `BaseStore` / `AsyncPostgresStore`.

### 3. Utilities (`langgraph_library.utils`)
- **`config.py`**: Helpers for runtime configuration, checkpoint TTL management, and context schemas.

## 🚀 Quick Usage Example

```python
from langgraph_library.graphs.supervisor import create_supervisor_graph
from langgraph_library.plugins.mcp_adapter import load_mcp_tools
from langgraph_library.plugins.memory_store import search_user_memory

# Import prebuilt compiled supervisor graph
graph = create_supervisor_graph()
```
