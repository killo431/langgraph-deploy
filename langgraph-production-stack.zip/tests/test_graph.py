"""Unit & Integration tests for LangGraph Agent Graph."""
import pytest
from langchain_core.messages import HumanMessage
from src.agent.graph import graph


def test_graph_initialization():
    """Verify graph compiles without errors."""
    assert graph is not None
    graph_nodes = set(graph.nodes.keys())
    assert "model" in graph_nodes
    assert "tools" in graph_nodes


@pytest.mark.asyncio
async def test_graph_invocation_basic():
    """Test basic graph invocation without tool calls."""
    inputs = {"messages": [HumanMessage(content="Hello!")]}
    result = await graph.ainvoke(inputs)
    assert "messages" in result
    assert len(result["messages"]) >= 2
