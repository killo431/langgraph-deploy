# Self-Hosted Production LangGraph Agent Server Stack

A complete, standalone, production-ready Docker deployment stack for LangGraph Agent Servers. Designed for enterprise self-hosting with PostgreSQL persistence, Redis streaming queues, semantic long-term memory, and human-in-the-loop execution.

---

## 🏗️ Stack Overview & Architecture

- **`langgraph-api`**: Self-hosted Agent Server API running on Python 3.12 (Wolfi image distro).
- **`langgraph-postgres`**: PostgreSQL 16 database storing thread state, checkpoints, assistants, runs, and vector memory.
- **`langgraph-redis`**: Redis 6 Pub/Sub message broker powering real-time Server-Sent Events (SSE) streaming.

---

## 🚀 Quickstart Deployment

### 1. Configure Environment Variables
Copy the template and fill in your API keys:
```bash
cp .env.example .env
```

Set your required keys inside `.env`:
```env
OPENAI_API_KEY=sk-proj-your-openai-key
LANGSMITH_API_KEY=lsv2_pt_your_langsmith_key
LANGGRAPH_CLOUD_LICENSE_KEY=your_license_key
```

### 2. Build the Agent Server Image
Build the container image using the LangGraph CLI:
```bash
langgraph build -t my-langgraph-agent:latest
```

### 3. Spin Up Docker Stack
Launch all services using Docker Compose:
```bash
docker compose up --build -d
```

---

## 🔬 Health Verification & Testing

Verify that the Agent Server is running and healthy:
```bash
curl http://localhost:8123/ok
```
*Expected Output:*
```json
{"ok": true}
```

### Run Python SDK Verification Client
To interact with your self-hosted graph:
```python
from langgraph_sdk import get_client

client = get_client(url="http://localhost:8123")

# Create a thread
thread = client.threads.create()

# Start an agent run
run = client.runs.create(
    thread_id=thread["thread_id"],
    assistant_id="agent",
    input={"messages": [{"role": "user", "content": "Search internal knowledge base for deployment policies."}]}
)
```

---

## 📋 Directory Structure

```
langgraph-production-stack/
├── docker-compose.yml           # Multi-container orchestration
├── Dockerfile                   # LangGraph Agent Server build specification
├── langgraph.json               # Server config, checkpointer TTL & vector store index
├── pyproject.toml               # Dependency specifications & project metadata
├── .env.example                 # Production environment variable template
├── README.md                    # Deployment guide and reference
├── src/
│   └── agent/
│       ├── __init__.py
│       ├── state.py             # TypedDict AgentState schema
│       ├── tools.py             # Custom tools and ToolNode definitions
│       ├── nodes.py             # Execution nodes & interrupt() logic
│       └── graph.py             # StateGraph definition and entrypoint
└── tests/
    └── test_graph.py            # Graph test suite
```
