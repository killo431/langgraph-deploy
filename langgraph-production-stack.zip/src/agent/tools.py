"""Custom tools and ToolNode definitions for the agent."""
from langchain_core.tools import tool
from langgraph.prebuilt import ToolNode


@tool
def search_knowledge_base(query: str) -> str:
    """Search internal knowledge base and vector database for information.
    
    Args:
        query: Search topic or keywords to look up.
    """
    return f"Retrieved knowledge base content for query: '{query}'. Internal policy: All sensitive actions require explicit manager approval."


@tool
def calculate_metrics(expression: str) -> str:
    """Perform mathematical and statistical calculation.
    
    Args:
        expression: Mathematical expression string (e.g., '15000 * 0.15').
    """
    try:
        allowed_chars = set("0123456789+-*/(). ")
        if not all(c in allowed_chars for c in expression):
            return "Error: Invalid characters in expression."
        result = eval(expression, {"__builtins__": {}})
        return f"Calculation Result: {result}"
    except Exception as e:
        return f"Error executing calculation: {str(e)}"


agent_tools = [search_knowledge_base, calculate_metrics]
tool_node = ToolNode(agent_tools)
