"""Node implementations, LLM invocations, and Human-in-the-Loop interrupts."""
import datetime
from typing import Any, Dict, Literal
from langchain_core.messages import AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END
from langgraph.types import Command, interrupt

from src.agent.state import AgentState
from src.agent.tools import agent_tools


model = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0
).bind_tools(agent_tools)

SYSTEM_PROMPT = SystemMessage(
    content=(
        "You are an enterprise AI assistant running on a self-hosted LangGraph Agent Server. "
        "Use available tools to assist users accurately. If sensitive operations require human approval, "
        "route execution through the human_approval node."
    )
)


def call_model(state: AgentState) -> Dict[str, Any]:
    """Invoke LLM with current conversation messages."""
    messages = [SYSTEM_PROMPT] + state["messages"]
    response = model.invoke(messages)
    return {"messages": [response]}


def human_approval_node(state: AgentState) -> Command[Literal["tools", "reject_action"]]:
    """Human-in-the-loop approval step using native interrupt() primitive."""
    last_message = state["messages"][-1]
    tool_calls = getattr(last_message, "tool_calls", [])
    
    approval_request = {
        "type": "human_approval_required",
        "pending_tool_calls": tool_calls,
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "instructions": "Respond with {'approved': True} to proceed or {'approved': False, 'reason': '...'} to reject."
    }
    
    decision = interrupt(approval_request)
    
    if isinstance(decision, dict) and decision.get("approved"):
        return Command(
            goto="tools",
            update={"approval_granted": True}
        )
    else:
        reason = decision.get("reason", "Action rejected by human reviewer.") if isinstance(decision, dict) else "Action rejected."
        return Command(
            goto="reject_action",
            update={"approval_granted": False, "rejection_reason": reason}
        )


def reject_action_node(state: AgentState) -> Dict[str, Any]:
    """Handle rejected human-in-the-loop actions cleanly."""
    reason = state.get("rejection_reason", "Action declined.")
    rejection_message = AIMessage(content=f"Operation halted: {reason}")
    return {"messages": [rejection_message]}


def should_continue(state: AgentState) -> Literal["human_approval", "tools", END]:
    """Conditional routing based on tool call sensitivity."""
    last_message = state["messages"][-1]
    if not hasattr(last_message, "tool_calls") or not last_message.tool_calls:
        return END
    
    return "tools"
