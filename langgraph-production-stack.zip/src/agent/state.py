"""State schemas and reducers for the LangGraph agent."""
from typing import Annotated, Any, Dict, List, Optional
from typing_extensions import TypedDict
from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages


class AgentState(TypedDict):
    """Primary state object for the agent graph."""
    messages: Annotated[List[AnyMessage], add_messages]
    context: Optional[str]
    approval_granted: Optional[bool]
    rejection_reason: Optional[str]
    metadata: Dict[str, Any]
