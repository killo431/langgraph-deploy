"""Compiled LangGraph StateGraph entrypoint."""
from langgraph.graph import END, START, StateGraph

from src.agent.nodes import call_model, human_approval_node, reject_action_node, should_continue
from src.agent.state import AgentState
from src.agent.tools import tool_node


builder = StateGraph(AgentState)

builder.add_node("model", call_model)
builder.add_node("tools", tool_node)
builder.add_node("human_approval", human_approval_node)
builder.add_node("reject_action", reject_action_node)

builder.add_edge(START, "model")
builder.add_conditional_edges(
    "model",
    should_continue,
    {
        "human_approval": "human_approval",
        "tools": "tools",
        END: END
    }
)
builder.add_edge("tools", "model")
builder.add_edge("reject_action", END)

graph = builder.compile()
