# LangGraph Production Stack with GitHub Actions CI/CD & BMAD Quality Gates

Production-ready, self-hosted LangGraph Agent Server stack complete with PostgreSQL persistence, Redis pub/sub, BMAD Spec-Driven Workflow Engine, and GitHub Actions CI/CD automation.

## CI/CD Workflows Included

- `.github/workflows/ci-testing.yml`: Runs Ruff linter, MyPy type checks, and PyTest integration tests against live PostgreSQL 16 & Redis service containers.
- `.github/workflows/cd-deploy.yml`: Builds multi-architecture Docker images (`amd64`/`arm64`), pushes to GHCR, performs Trivy vulnerability scans, and verifies server `/ok` health endpoint.
- `.github/workflows/qol-bmad-pr-automation.yml`: Automates PR labeling, BMAD spec compliance verification, and automated gate status comments.
- `.github/workflows/qol-maintenance.yml`: Weekly automated dependency vulnerability audits (`pip-audit`) and cache cleanup.

## Quickstart

```bash
cp .env.example .env
docker compose up --build -d
curl http://localhost:8123/ok
```
