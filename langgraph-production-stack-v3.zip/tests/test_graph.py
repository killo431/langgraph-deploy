import pytest
from src.agent.graph import graph

def test_graph_execution():
    result = graph.invoke({"messages": [], "context": "", "approval_granted": False})
    assert "context" in result
    assert "Processed" in result["context"]
