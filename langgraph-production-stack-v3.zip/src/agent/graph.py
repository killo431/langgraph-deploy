from langgraph.graph import StateGraph, START, END
from src.agent.state import AgentState

def model_node(state: AgentState) -> dict:
    return {"context": "Processed user query through LangGraph state graph."}

builder = StateGraph(AgentState)
builder.add_node("model", model_node)
builder.add_edge(START, "model")
builder.add_edge("model", END)

graph = builder.compile()
