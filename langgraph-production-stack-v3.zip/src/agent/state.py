from typing import TypedDict, Annotated, List, Any
import operator
from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages

class AgentState(TypedDict):
    messages: Annotated[List[AnyMessage], add_messages]
    context: str
    approval_granted: bool
