"""
LangGraph Workflow, Plugin, and Data Source Marketplace
Enables runtime graph registration, plugin management, and dynamic data source ingestion into LangGraph's long-term vector Store.
"""
from typing import Dict, Any, List, Callable, Optional, Tuple
from dataclasses import dataclass, field
import datetime

@dataclass
class MarketplaceItem:
    item_id: str
    name: str
    category: str  # 'graph', 'plugin', 'mcp_server', 'data_source'
    description: str
    entrypoint: Any
    metadata: Dict[str, Any] = field(default_factory=dict)

class WorkflowMarketplace:
    """Central registry for LangGraph Graphs, MCP Adapters, and Middleware Plugins."""
    
    def __init__(self):
        self._registry: Dict[str, MarketplaceItem] = {}

    def register_graph(self, graph_id: str, graph_obj: Any, description: str = "", metadata: Dict[str, Any] = None):
        self._registry[graph_id] = MarketplaceItem(
            item_id=graph_id,
            name=graph_id,
            category="graph",
            description=description,
            entrypoint=graph_obj,
            metadata=metadata or {}
        )

    def register_mcp_server(self, server_id: str, server_config: Dict[str, Any], description: str = ""):
        self._registry[server_id] = MarketplaceItem(
            item_id=server_id,
            name=server_id,
            category="mcp_server",
            description=description,
            entrypoint=server_config,
            metadata={"transport": server_config.get("transport", "http")}
        )

    def get(self, item_id: str) -> Optional[MarketplaceItem]:
        return self._registry.get(item_id)

    def list_available(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        return [
            {
                "id": item.item_id,
                "name": item.name,
                "category": item.category,
                "description": item.description,
                "metadata": item.metadata
            }
            for item in self._registry.values()
            if category is None or item.category == category
        ]


class SourceIngestionMarketplace:
    """Helper for adding knowledge sources and documentation directly into LangGraph's BaseStore."""

    def __init__(self, store: Optional[Any] = None):
        self.store = store

    async def ingest_text_source(
        self, 
        namespace: Tuple[str, ...], 
        source_id: str, 
        content: str, 
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        doc_item = {
            "text": content,
            "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "metadata": metadata or {}
        }
        if self.store and hasattr(self.store, "aput"):
            await self.store.aput(namespace, source_id, doc_item)
        return {"status": "ingested", "namespace": namespace, "source_id": source_id, "size_chars": len(content)}

    async def search_sources(
        self, 
        namespace: Tuple[str, ...], 
        query: str, 
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        if self.store and hasattr(self.store, "asearch"):
            results = await self.store.asearch(namespace, query=query, limit=limit)
            return [{"key": r.key, "value": r.value} for r in results]
        return [{"status": "mock_search", "query": query, "message": "Store instance required for live search"}]
