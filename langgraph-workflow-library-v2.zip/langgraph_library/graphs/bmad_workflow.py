"""
BMAD (Breakthrough Method for Agile AI-Driven Development) Phase-Gated Workflow
Covers the full SDLC: Product Manager (PRD) -> Software Architect (Design + HITL Gate) -> Scrum Master (Story Breakdown) -> Developer (Parallel Execution via Send API) -> QA Agent (Verification & Sign-off).
"""
from typing import TypedDict, Annotated, List, Dict, Any
import operator
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt, Command
from langgraph.constants import Send

class BMadState(TypedDict):
    feature_request: str
    prd_spec: str
    architecture_doc: str
    stories: List[str]
    approved_stories: List[str]
    qa_reports: Annotated[List[str], operator.add]

def product_manager_node(state: BMadState) -> dict:
    request = state["feature_request"]
    prd = f"# PRD: {request}\n\n## Acceptance Criteria\n- Clean API boundaries\n- Test coverage > 85%."
    return {"prd_spec": prd}

def architect_node(state: BMadState) -> dict:
    prd = state["prd_spec"]
    arch = f"# Architecture\nBased on:\n{prd}\n\n## Tech Stack\n- FastAPI\n- LangGraph StateGraph\n- PostgreSQL"
    
    review_decision = interrupt({
        "phase": "Architectural Review Gate",
        "prd": prd,
        "proposed_architecture": arch,
        "instructions": "Approve architecture or provide revision feedback."
    })
    
    if not review_decision.get("approved", False):
        raise ValueError(f"Architecture rejected by Human Lead: {review_decision.get('feedback')}")
        
    return {"architecture_doc": arch}

def scrum_master_node(state: BMadState) -> dict:
    stories = [
        "Story 1: Implement Core State Schemas & Reducers",
        "Story 2: Implement External API Adapters & ToolNode"
    ]
    return {"stories": stories}

def map_stories_to_developers(state: BMadState):
    return [Send("developer_node", {"story": story, "arch": state["architecture_doc"]}) for story in state["stories"]]

class DevTaskState(TypedDict):
    story: str
    arch: str

def developer_node(state: DevTaskState) -> dict:
    story = state["story"]
    qa_result = f"QA Passed for '{story}': All acceptance criteria verified."
    return {"qa_reports": [qa_result]}

def qa_signoff_node(state: BMadState) -> dict:
    reports = state["qa_reports"]
    return {"approved_stories": reports}

builder = StateGraph(BMadState)
builder.add_node("product_manager", product_manager_node)
builder.add_node("architect", architect_node)
builder.add_node("scrum_master", scrum_master_node)
builder.add_node("developer_node", developer_node)
builder.add_node("qa_signoff", qa_signoff_node)

builder.add_edge(START, "product_manager")
builder.add_edge("product_manager", "architect")
builder.add_edge("architect", "scrum_master")

builder.add_conditional_edges("scrum_master", map_stories_to_developers, ["developer_node"])
builder.add_edge("developer_node", "qa_signoff")
builder.add_edge("qa_signoff", END)

bmad_workflow = builder.compile()
