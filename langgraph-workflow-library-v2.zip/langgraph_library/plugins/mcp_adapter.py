"""
Model Context Protocol (MCP) Client Adapters for LangGraph
Connects LangGraph agents to external MCP tool servers (e.g. GitHub PRs, SonarQube, File Systems).
"""
from typing import Dict, Any, List, Optional

class MCPToolAdapter:
    def __init__(self, server_url: Optional[str] = None, command: Optional[str] = None, args: Optional[List[str]] = None):
        self.server_url = server_url
        self.command = command
        self.args = args or []

    def get_server_config(self) -> Dict[str, Any]:
        if self.server_url:
            return {"transport": "http", "url": self.server_url}
        return {"transport": "stdio", "command": self.command, "args": self.args}

    async def get_langchain_tools(self) -> List[Any]:
        return [
            {
                "name": "github_create_pull_request",
                "description": "Creates a GitHub PR for verified story branches",
                "parameters": {"title": "str", "body": "str", "head": "str", "base": "str"}
            },
            {
                "name": "sonarqube_check_quality_gate",
                "description": "Checks SonarQube code security and bug quality gates for PRs",
                "parameters": {"project_key": "str", "pull_request_id": "str"}
            }
        ]
