# LangGraph Workflow & Plugin Library (v2.0)

A production-grade, modular library of prebuilt graph topologies, enterprise plugin adapters, BMAD spec-driven software development workflows, and a dynamic Workflow & Source Marketplace for LangGraph Agent Servers.

---

## 🚀 Key Modules Included

### 1. `langgraph_library.marketplace` (Marketplace Registry)
- **`WorkflowMarketplace`**: Central registry to dynamically register, discover, load, and run graphs, MCP adapters, and plugins at runtime.
- **`SourceIngestionMarketplace`**: Enables agents and users to dynamically ingest, chunk, embed, and query external data sources (documents, repos, URLs, specs) into LangGraph's cross-thread vector `Store` (`AsyncPostgresStore`).

### 2. `langgraph_library.graphs.bmad_workflow` (BMAD Spec-Driven SDLC)
- **BMAD Agent Squad**: Product Manager (PRD), Architect (System Design + HITL Gate), Scrum Master (Story Breakdown), Developer (Parallel Code Execution via `Send`), QA Agent (Acceptance Verification).
- **Phase-Gated Quality Control**: Enforces human architectural approval using `interrupt()` and `Command(resume=...)` to stop context drift.

### 3. `langgraph_library.plugins.mcp_adapter` (MCP Tool Integration)
- **`MCPToolAdapter`**: Universal Anthropic Model Context Protocol (MCP) wrapper supporting `stdio` and `http/sse` connections to GitHub (PRs, Issues), SonarQube (Quality Gates), and local FastMCP servers.

### 4. `langgraph_library.graphs` (Core Agent Topologies)
- **`supervisor`**: Multi-Agent Supervisor with dynamic dispatching via `Command(goto=...)`.
- **`hitl_approval`**: Native state interruption and human review handling.
- **`map_reduce`**: Parallel task processing using the `Send` API.
- **`evaluator_optimizer`**: Self-correcting reflection loops.

---

## 📦 Quick Start & Usage

```python
from langgraph_library.marketplace import WorkflowMarketplace, SourceIngestionMarketplace
from langgraph_library.graphs.bmad_workflow import bmad_workflow
from langgraph_library.plugins.mcp_adapter import MCPToolAdapter

# 1. Initialize Marketplace
marketplace = WorkflowMarketplace()
marketplace.register_graph("bmad_sdlc", bmad_workflow)

# 2. Add Sources to Store
ingestor = SourceIngestionMarketplace()
await ingestor.ingest_text_source(
    namespace=("team_docs", "specs"),
    source_id="prd_auth_v1",
    content="JWT authentication with 15-min expiry and PostgreSQL token blacklisting.",
    metadata={"author": "PM Agent", "phase": "PRD"}
)

# 3. Connect MCP Servers (e.g. GitHub / SonarQube)
mcp = MCPToolAdapter(server_url="http://localhost:8000/mcp")
github_tools = await mcp.get_langchain_tools()
```
